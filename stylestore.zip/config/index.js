import fetch from './globalConfig';
import { db, storage } from './firebaseConfig';

export {
    fetch,
    db,
    storage,
};
